<template>
    <div>
        <h1>Vue Cart</h1>
        <!-- <CartItem :items="items" /> -->
        <ul>
            <li v-for="item in items" :key="item.id">
                <img :src="item.imgsrc" :alt="item.name" />
                <!-- :src="require(item.imgsrc)" -->
                <div>{{ item.name }}</div>
                <div>{{ item.price }}</div>
            </li>
        </ul>
        <img src="@/assets/7nl76pa-hp-14s-dk0089au-14-inch-laptop.jpg" alt="">
    </div>
</template>


<script lang="ts">

import { Component, Prop, Vue } from 'vue-property-decorator';
import Product from '@/models/Product.ts';
// import CartItem from '@/components/CartItem.vue';

// @Component({
//   components: {
//     CartItem
//   }
// })
export default class Cart extends Vue {
    private items: Array<Product> = [
        new Product(1, 'Notebook 1', 30, '@/assets/7nl76pa-hp-14s-dk0089au-14-inch-laptop.jpg'), 
        new Product(2, 'Notebook 2', 60, '@/assets/80d57feac746c94ab094374eea5591662e90ff558c448b879c58861e57f882f7.jpg'), 
        new Product(3, 'Notebook 3', 50, '@/assets/m509da-br139t-asus-vivobook-m509-laptop.jpg'), 
        new Product(4, 'Notebook 4', 45, '@/assets/mi_note_1.jpg'), 
        new Product(5, 'Notebook 5', 55, '@/assets/MicrosoftSurfaceLaptop3-15__1__02.jpg'), 
        new Product(6, 'Notebook 6', 85, '@/assets/02107b3c662d9bcfb778e7b95aec7d0b625d08873db3ccdd143f266e905ebbda.jpg'), 
    ];

     beforeCreate() {
        console.log(this.items);
     }
}

</script>



