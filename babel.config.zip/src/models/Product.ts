export default class Product {
    id = 0;
    name = '';
    price = 0;
    imgsrc = '';

    constructor(id:number, name:string, price:number, imgsrc:string) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.imgsrc = imgsrc;
    }
    // getSrc() {
    //     return require(this.imgsrc);
    // }
}
